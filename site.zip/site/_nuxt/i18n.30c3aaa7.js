const a={legacy:!1,locale:"en",fallbackLocale:"en"};export{a as default};
